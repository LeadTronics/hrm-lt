import React,{useState} from 'react';
import './Login.css';
import { useForm } from "react-hook-form";
import preview from '../../img/preview.png';
import Button from '../../Components/Button/Button';
// import axios from 'axios';
import { Link } from 'react-router-dom';
//import swal from 'sweetalert';
// import {useNavigate} from "react-router-dom"
function Login() {
  const { register, handleSubmit, formState: { errors } } = useForm();
  // const navigate = useNavigate();
  // const[items,setItems]=useState();
  const onSubmit = data =>{
    console.log('data');
    // axios.post(``,data )
    // .then(res => {
    //     console.log(res);
    //     console.log(res.data);
    //     setItems(res.data);
    //     console.log(items);
    //     navigate('/dashboard');
    //     reset();    
    // })
  } 

    return (
       <>
       <section className='img-vr'></section>
          <section className='Login-Form-HRM'>
              <div className='container login-form-cont'>
                <div className='row Loginform-outerdiv'>
                    <div className='inner-div'>
                      <div className='row'>
                          {/* <div className='col-lg-6 p-4'>
                            <div className='blue-circle'></div>
                                <img className='img-Hr-login img-fluid' src={preview} alt="Login-Form-HR"></img>
                              </div> */}
                              <div className='col-lg-12 p-4 Login-form-col'>
                                  <div className='Login_Title'>
                                  <h2 className='d-flex justify-content-center align-items-center my-2'>Login</h2>
                                  </div>
                                <div className='Login-form'>
                                    <form className="Login-form-inpute" onSubmit={handleSubmit(onSubmit)}>
                                    
                                        <div className='d-flex justify-content-center'>
                                            <div className='form-icon'>
                                              <i className='fa fa-user'></i>
                                            </div>
                                            <div className="form-group">
                                              <input type="email" name="email" className="form-control form-in" {...register("email", { required: true })} id="exampleInputEmail1" placeholder="Enter email"/>
                                              <span className='form-error-login'>
                                                  {errors.email && "Please Enter email."}
                                                  {errors?.email?.type === "maxLength" && (
                                                  <p >email cannot exceed 50 characters</p>
                                                  )}
                                              </span>
                                            </div>
                                        </div>
                                        <div className='d-flex justify-content-center'>
                                            <div className='form-icon'>
                                              <i className='fa fa-lock'></i>
                                            </div>
                                            <div className="form-group">
                                              <input type="password" name="password" className="form-control form-in" {...register("password", { required: true })} id="exampleInputPassword1" placeholder="Password"/>
                                              <span className='form-error-login'>
                                                  {errors.password && "Please Enter Correct Password."}
                                                  {errors?.password?.type === "maxLength" && (
                                                  <p>Password cannot exceed 50 characters</p>
                                                  )}
                                              </span>
                                            </div>
                                        </div>
                                        <div className='d-flex justify-content-center'>
                                            <div className='form-icon sign-in-icon'>
                                                  <i className='fa fa-arrow-right'></i>
                                            </div>
                                            <div className='d-flex justify-content-center align-items-center w-100'>
                                               <Link to="/dashboard">
                                                 <Button classNames='Login-btn1' btnName="Login" type="submit"></Button>
                                                </Link>
                                            </div>
                                        </div>
                                        {/* <div className='d-flex justify-content-center align-items-center pt-4'>
                                            <span className='forget-password'><a href="" style={{"fontsize":"14px"}}>Forgot Username / Password</a></span>
                                        </div> */}
                                    </form>
                                </div>
                          </div>
                        </div>
                    </div>
                </div>
              </div>
          </section>
       </>  
    )
}

export default Login