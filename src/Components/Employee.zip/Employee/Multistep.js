import { Container, Row, Col } from "react-bootstrap";
import { useState } from "react";
import StepOne from "./StepOne";
import StepTwo from "./StepTwo";
import StepThree from "./StepThree";
import StepFour from "./StepFour";
import Final from "./Final";

function Multistep() {
    //state for steps
    const [step, setstep] = useState(1);
    
    //state for form data
    const [formData, setFormData] = useState({
      name: "",
      email: "",
      phone:"",
      gender:"",
      // Phone_Number2:"",
      // maritial_sta:"",
      // blood_group:"",
      // address:"",
      // per_address:"",
      // birthdate:"",


      empId: "",
      designation:"",
      company: "",
      department:"",
      joiningDate:"",
      // salary:"",
      // residate:"",
      // creadit_leave:"",
      // active:"",
      // inactive:"",

      // accName: "",
      // accno: "",
      // bank_name:"",
      // branch_name:"",
      // brach_location:"",
      // bank_ifsc:"",
      // Pan:"",

      // profile: "",
      // pass_photo:"",
      // ID_proof:"",
      // off_latter:"",
      // joining_latter:"",
      // exp_latter:"",

    })
  
    // function for going to next step by increasing step state by 1
    const nextStep = () => {
      setstep(step + 1);
    };
  
    // function for going to previous step by decreasing step state by 1
    const prevStep = () => {
      setstep(step - 1);
    };
  
    // handling form input data by taking onchange value and updating our previous form data state
    const handleInputData = input => e => {
      // input value from the form
      const {value } = e.target;
       
      //updating for data state taking previous state and then adding new value to create new object
      setFormData(prevState => ({
        ...prevState,
        [input]: value
    }));
    }
  
  
  // javascript switch case to show different form in each step
    switch (step) {
      // case 1 to show stepOne form and passing nextStep, prevStep, and handleInputData as handleFormData method as prop and also formData as value to the fprm
      case 1:
        return (
          <div className="" style={{padding:'2%'}}>
              <Row>
                <Col>
                  <StepOne nextStep={nextStep} handleFormData={handleInputData} values={formData} />
                </Col>
              </Row>
          </div>
        );
      // case 2 to show stepTwo form passing nextStep, prevStep, and handleInputData as handleFormData method as prop and also formData as value to the fprm
      case 2:
        return (
          <div className="" style={{padding:'2%'}}>
              <Row>
                <Col>
                  <StepTwo nextStep={nextStep} prevStep={prevStep} handleFormData={handleInputData} values={formData} />
                </Col>
              </Row>
          </div>
        );
      // case 3 to show stepTwo form passing nextStep, prevStep, and handleInputData as handleFormData method as prop and also formData as value to the fprm
      case 3:
        return (
          <div className="" style={{padding:'2%'}}>
              <Row>
                <Col>
                  <StepThree nextStep={nextStep} prevStep={prevStep} handleFormData={handleInputData} values={formData} />
                </Col>
              </Row>
          </div>
        );
        // case 4 to show stepTwo form passing nextStep, prevStep, and handleInputData as handleFormData method as prop and also formData as value to the fprm
      case 4:
        return (
          <div className="" style={{padding:'2%'}}>
              <Row>
                <Col>
                  <StepFour nextStep={nextStep} prevStep={prevStep} handleFormData={handleInputData} values={formData} />
                </Col>
              </Row>
          </div>
        );
        // Only 5 formData is passed as prop to show the final value at form submit
      case 5:
        return (
          <div className="" style={{padding:'2%'}}>
              <Row>
                <Col>
                  <Final values={formData}  />
                </Col>
              </Row>
          </div>
        );
      // default case to show nothing
      default:
        return (
          <div className="App">
          </div>
        );
    }
  }
  
  export default Multistep;