import './Multistep.css'
import {Row} from 'react-bootstrap';
import React,{useState} from 'react';
import Topbar from '../TopBar/Topbar';
import Multistep from './Multistep';
import Footer from '../Footer/Footer'
import ScrolltoTop from '../ScrolltoTop/ScrolltoTop'

const Employee = ()=>{

    return(
        <>
            <div style={{backgroundColor:'#f1f4fb'}}>
                <Topbar/>
                    <div  className='addemp_martop'>
                        <Row>
                            <Multistep  />                            
                        </Row>
                    </div> 
                 <ScrolltoTop/>
                <Footer />
            </div>      
        </>
    )
}
export default Employee; 