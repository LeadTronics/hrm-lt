import React,{useState} from "react";
import { Card ,Col} from "react-bootstrap";
import Button from '../Button/Button';
import axios from "axios";
import Swal from 'sweetalert';
import {EMPLOYEE_API} from '../../endpoint'
import {useNavigate} from "react-router-dom"

const Final = ({ values }) => {
  const navigate = useNavigate()
    //destructuring the object from values
  const { name, email,phone, empId,designation, department,company,joiningDate,profile,gender } = values;
  
  let tok = JSON.parse(localStorage.getItem("token"));

  const allSubmit = ()=>{
    console.log(values);
      axios.post(EMPLOYEE_API, values,{ headers: { Authorization: `Bearer ${tok}` } })
      .then(res => {
          console.log(res);
          console.log(res.data);

        // Swal.fire({
        //   position: 'centerd',
        //   icon: 'success',
        //   title: 'Your Data has been saved',
        //   showConfirmButton: false,
        //   timer: 1500
        //   })
          // if(res.status === 200)
          // {
          //      navigate('/allemployee');  
          // }
        })
          // reset();    
  }
  
  return (
    <>
    <Col className="perform_box"> 
    <h5 className='perform_head'>Final Details</h5>
      <Card style={{ textAlign: "left" }}>
        <Card.Body>
          <p>
            <strong>Name :</strong> {name}{" "}
          </p>
          <p>
            <strong>Business Email:</strong> {email}{" "}
          </p>
          <p>
            <strong>Employee Id :</strong> {empId}{" "}
          </p>
          <p>
            <strong>Deprtment :</strong> {department}{" "}
          </p>
          <p><strong>Company Name:</strong> {company}{""}</p>
          <p><strong>Profile:</strong>{profile}</p>
        </Card.Body>
      </Card>
        <div className="my-2">
          {/* <Link to="/allemployee">  */}
              <Button fun={allSubmit} classNames="allbtncss" type="submit" btnName="Save Data"/>
          {/* </Link> */}
        </div>
    </Col>
    </>
  );
};

export default Final;