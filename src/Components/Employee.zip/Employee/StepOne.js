import React, { useState } from "react";
import { Form } from "react-bootstrap";
import validator from "validator";
import { Col ,Row} from "react-bootstrap";
import Button from '../Button/Button';

// creating functional component ans getting props from app.js and destucturing them
const StepOne = ({ nextStep, handleFormData, values}) => {
  //creating error state for validation
  const [error, setError] = useState(false);

  // after form submit validating the form data using validator
  const submitFormData = (e) => {
    e.preventDefault();

    // checking if value of first name and last name is empty show error else take to step 2
    if (
      validator.isEmpty(values.name) ||
      validator.isEmpty(values.email)
    ) {
      setError(true);
    } else {
      nextStep();
    }
  };

  //state for steps
  const [step2, setstep2] = useState(1);
  // function for going to next step by increasing step state by 1
     const nextStep2 = () => {
      setstep2(step2 + 1);
    };
  
  // function for going to previous step by decreasing step state by 1
    const prevStep2 = () => {
      setstep2(step2 - 1);
    };


  return (
    <>
    <div>

        <Col className="perform_box1 my-3">
          {/* Progress Bar */}
            <ul id="progressbar"> 
              <li id="step1" className={step2===1 ? 'active' : 'active2'} ><strong>Personal Details</strong></li>
              <li  id="step2" className={step2===2 ? 'active' : 'active2'} ><strong>Company Details</strong></li>
              <li  id="step3" className={step2===3 ? 'active' : 'active2'} ><strong>Bank Details</strong></li>
              <li id="step4"  className={step2===4 ? 'active' : 'active2'}><strong>File Details</strong></li>
            </ul> 
        </Col>
         
        <Col className="perform_box">                        
          <h5 className='perform_head'>Employee Personal Details</h5>  
          <Form onSubmit={submitFormData}>
            <Row>
              <Col lg="6" md="6" sm="12" className="my-2">
                <Form.Group className="mb-3">
                    <Form.Control
                      style={{ border: error ? "1px solid red" : "" }}
                      name="name"
                      defaultValue={values.name}
                      type="text"
                      placeholder="Name"
                      onChange={handleFormData("name")}
                    />
                    {error ? (
                      <Form.Text style={{ color: "red"}}>
                          Name is a required field
                      </Form.Text>
                    ) : (
                      ""
                    )}
                </Form.Group>
              </Col>
              <Col lg="6" md="6" sm="12" className="my-2">
                <Form.Group className="mb-3">
                  <Form.Control
                    style={{ border: error ? "1px solid red" : "" }}
                    name="email"
                    defaultValue={values.email}
                    type="text"
                    placeholder="Business Email "
                    onChange={handleFormData("email")}
                  />
                  {error ? (
                    <Form.Text style={{ color: "red" }}>
                      Business Email is a required field
                    </Form.Text>
                  ) : (
                    ""
                  )}
                </Form.Group>
              </Col>
            </Row>
            <Row>
              <Col lg="6" md="6" sm="12" className="my-2">
                <Form.Group className="mb-3">
                    <Form.Control
                      style={{ border: error ? "1px solid red" : "" }}
                      name="phone"
                      defaultValue={values.phone}
                      type="number"
                      placeholder="Phone Number"
                      onChange={handleFormData("phone")}
                    />
                    {error ? (
                      <Form.Text style={{ color: "red" }}>
                        Phone Number is a required field
                      </Form.Text>
                    ) : (
                      ""
                    )}
                </Form.Group>
              </Col>
              {/* <Col lg="6" md="6" sm="12" className="my-2">
                <Form.Group className="mb-3">
                  <Form.Control
                    style={{ border: error ? "1px solid red" : "" }}
                    name="salary"
                    defaultValue={values.Phone_Number2}
                    type="number"
                    placeholder="Phone Number2 "
                    onChange={handleFormData("Phone_Number2")}
                  />
                  {error ? (
                    <Form.Text style={{ color: "red" }}>
                      Phone Number is a optional field
                    </Form.Text>
                  ) : (
                    ""
                  )}
                </Form.Group>
              </Col> */}
            </Row>
            {/* <Row>
              <Col lg="6" md="6" sm="12" className="my-2">
                <Form.Group className="mb-3">
                    <Form.Select  style={{ border: error ? "1px solid red" : "" }}
                      name="maritial_sta"
                      defaultValue={values.maritial_sta}
                      type="text"
                      placeholder="Maritial Status"
                      onChange={handleFormData("maritial_sta")}>
                    <option>Select Status</option>
                    <option value="1">Married</option>
                    <option value="2">Unmarried</option>
                  </Form.Select>
                    {error ? (
                      <Form.Text style={{ color: "red" }}>
                         Maritial Status is a required field
                      </Form.Text>
                    ) : (
                      ""
                    )}
                </Form.Group>
              </Col>
              <Col lg="6" md="6" sm="12" className="my-2">
                <Form.Group className="mb-3">
                  <Form.Select  style={{ border: error ? "1px solid red" : "" }}
                    name="blood_group"
                    defaultValue={values.blood_group}
                    type="text"
                    placeholder="Blood Group "
                    onChange={handleFormData("blood_group")}>
                  <option>Select Bloog Group</option>
                  <option value="1">O-</option>
                  <option value="1">O+</option>
                  <option value="2">A+</option>
                  <option value="3">B+</option>
                  <option value="3">AB</option>
                </Form.Select>
                  {error ? (
                    <Form.Text style={{ color: "red" }}>
                      Blood Group is a required field
                    </Form.Text>
                  ) : (
                    ""
                  )}
                </Form.Group>
              </Col>
            </Row> */}
            {/* <Row>
              <Col lg="6" md="6" sm="12" className="my-2">
                <Form.Group className="mb-3">
                   <Form.Control as="textarea" rows={3} 
                      style={{ border: error ? "1px solid red" : "" }}
                      name="address"
                      defaultValue={values.address}
                      type="text"
                      placeholder="Address"
                      onChange={handleFormData("address")}
                    />
                    {error ? (
                      <Form.Text style={{ color: "red" }}>
                        Address is a required field
                      </Form.Text>
                    ) : (
                      ""
                    )}
                </Form.Group>
              </Col>
              <Col lg="6" md="6" sm="12" className="my-2">
                <Form.Group className="mb-3" controlId="exampleForm.ControlTextarea1">
                  <Form.Control as="textarea" rows={3} 
                    style={{ border: error ? "1px solid red" : "" }}
                    name="per_address"
                    defaultValue={values.per_address}
                    type="text"
                    placeholder="Permenant Address "
                    onChange={handleFormData("per_address")}/>
                      {error ? (
                      <Form.Text style={{ color: "red" }}>
                        Permenant Address is a required field
                      </Form.Text>
                    ) : (
                      ""
                    )}
                </Form.Group>
              </Col>
            </Row> */}
            <Row>
              {/* <Col>
                <Form.Group className="mb-3">
                <div style={{textAlign:'justify'}}>Your Birthdate</div>
                    <Form.Control
                      style={{ border: error ? "1px solid red" : "" }}
                      name="birthdate"
                      defaultValue={values.birthdate}
                      type="date"
                      placeholder="Birthdate "
                      onChange={handleFormData("birthdate")}
                    />
                    {error ? (
                      <Form.Text style={{ color: "red" }}>
                        Birthdate is a required field
                      </Form.Text>
                    ) : (
                      ""
                    )}
                  </Form.Group>
              </Col> */}
              <Col>
                  <div  className="mt-4" style={{textAlign:'justify'}}>
                    <label className="me-2">Select Gender</label>
                    <Form.Check
                        inline
                        label="Male"
                        name="gender"
                        type='radio'                      
                        defaultValue={values.gender}
                        onChange={handleFormData("gender")}                      
                      />
                    <Form.Check
                        inline
                        label="Female"
                        name="gender"
                        type='radio'     
                        defaultValue={values.gender}
                        onChange={handleFormData("gender")}                     
                      />
                        {error ? (
                      <Form.Text style={{ color: "red" }}>
                        Gender is a required field
                      </Form.Text>
                    ) : (
                      ""
                    )}
                  </div>            
              </Col>
            </Row>
            <div style={{ textAlign: "end" }}>
            <Button fun={nextStep2} classNames="allbtncss" type="submit" btnName="Continue"/>
            </div>
          </Form>
        </Col>
    </div>
    </>
  );
};

export default StepOne;