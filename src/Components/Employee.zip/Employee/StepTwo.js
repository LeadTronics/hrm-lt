import React, { useState } from "react";
import { Form } from "react-bootstrap";
import validator from "validator";
import { Col,Row } from "react-bootstrap";
import Button from '../Button/Button';


// creating functional component ans getting props from app.js and destucturing them
const StepTwo = ({ nextStep, handleFormData, prevStep, values }) => {
   //creating error state for validation
  const [error, setError] = useState(false);

    // after form submit validating the form data using validator
  const submitFormData = (e) => {
    e.preventDefault();
    console.log(values);

     // checking if value of first name and last name is empty show error else take to next step
    if (validator.isEmpty(values.empId) || validator.isEmpty(values.department) || validator.isEmpty(values.designation)) {
      setError(true);
    } else {
      nextStep();
    }
  };
  

   //state for steps
   const [step2, setstep2] = useState(2);
   // function for going to next step by increasing step state by 1
      const nextStep2 = () => {
       setstep2(step2 + 1);
     };
   
   // function for going to previous step by decreasing step state by 1
     const prevStep2 = () => {
       setstep2(step2 - 1);
     };

  return (
    <>
      <Col className="perform_box1 my-3">
          {/* Progress Bar */}
            <ul id="progressbar"> 
              <li id="step1" className={step2===1 ? 'active' : 'active2'}  ><strong>Personal Details</strong></li>
              <li  id="step2" className={step2===2 ? 'active' : 'active2'}  ><strong>Company Details</strong></li>
              <li  id="step3" className={step2===3 ? 'active' : 'active2'} ><strong>Bank Details</strong></li>
              <li id="step4"  className={step2===4 ? 'active' : 'active2'}><strong>File Details</strong></li>
            </ul> 
      </Col> 

      <Col className="perform_box"> 
        <h5 className='perform_head'>Company Details</h5>
          <Form onSubmit={submitFormData}>
            <Row>
              <Col lg="6" md="6" sm="12" className="my-2">
                <Form.Group className="mb-3">
                    <Form.Control
                      style={{ border: error ? "1px solid red" : "" }}
                      name="empId"
                      defaultValue={values.empId}
                      type="text"
                      placeholder="empId"
                      onChange={handleFormData("empId")}
                    />
                    {error ? (
                      <Form.Text style={{ color: "red" }}>
                        Employee id is a required field
                      </Form.Text>
                    ) : (
                      ""
                    )}
                </Form.Group>
              </Col>
              <Col lg="6" md="6" sm="12" className="my-2">
                <Form.Group className="mb-3">
                  <Form.Control
                    style={{ border: error ? "1px solid red" : "" }}
                    name="department"
                    defaultValue={values.company}
                    type="text"
                    placeholder="company "
                    onChange={handleFormData("company")}
                  />
                  {error ? (
                    <Form.Text style={{ color: "red" }}>
                      Department is a required field
                    </Form.Text>
                  ) : (
                    ""
                  )}
                </Form.Group>
              </Col>
            </Row>
            <Row>
              <Col lg="6" md="6" sm="12" className="my-2">
                <Form.Group className="mb-3">
                    <Form.Control
                      style={{ border: error ? "1px solid red" : "" }}
                      name="designation"
                      defaultValue={values.designation}
                      type="text"
                      placeholder="designation"
                      onChange={handleFormData("designation")}
                    />
                    {error ? (
                      <Form.Text style={{ color: "red" }}>
                       Designation is a required field
                      </Form.Text>
                    ) : (
                      ""
                    )}
                </Form.Group>
              </Col>
              {/* <Col lg="6" md="6" sm="12" className="my-2">
                <Form.Group className="mb-3">
                  <Form.Control
                    style={{ border: error ? "1px solid red" : "" }}
                    name="salary"
                    defaultValue={values.salary}
                    type="number"
                    placeholder="salary "
                    onChange={handleFormData("salary")}
                  />
                  {error ? (
                    <Form.Text style={{ color: "red" }}>
                      Salary is a required field
                    </Form.Text>
                  ) : (
                    ""
                  )}
                </Form.Group>
              </Col> */}
            </Row>
            <Row>
              <Col lg="6" md="6" sm="12" className="my-2">
              <div style={{textAlign:'justify'}}>Your Date of Joinning</div>
                <Form.Group className="mb-3">
                    <Form.Control
                      style={{ border: error ? "1px solid red" : "" }}
                      name="joindate"
                      defaultValue={values.joiningDate}
                      type="date"
                      placeholder="Join Date"
                      onChange={handleFormData("joiningDate")}
                    />
                    {error ? (
                      <Form.Text style={{ color: "red" }}>
                        Date of Joinning is a required field
                      </Form.Text>
                    ) : (
                      ""
                    )}
                </Form.Group>
              </Col>
              {/* <Col lg="6" md="6" sm="12" className="my-2">
              <div style={{textAlign:'justify'}}>Your Date of Resignation</div>
                <Form.Group className="mb-3">
                  <Form.Control
                    style={{ border: error ? "1px solid red" : "" }}
                    name="residate"
                    defaultValue={values.residate}
                    type="date"
                    placeholder="Resignation Date "
                    onChange={handleFormData("residate")}
                  />
                  {error ? (
                    <Form.Text style={{ color: "red" }}>
                       Date of Resignation is a required field
                    </Form.Text>
                  ) : (
                    ""
                  )}
                </Form.Group>
              </Col> */}
            </Row>
            <Row>
              <Col lg="6" md="6" sm="12" className="my-2">
                <Form.Group className="mb-3">
                    <Form.Control
                      style={{ border: error ? "1px solid red" : "" }}
                      name="department"
                      defaultValue={values.department}
                      type="text"
                      placeholder="department"
                      onChange={handleFormData("department")}
                    />
                    {error ? (
                      <Form.Text style={{ color: "red" }}>
                        Creadit Leaves is a required field
                      </Form.Text>
                    ) : (
                      ""
                    )}
                </Form.Group>
              </Col>
              
              {/* <Col lg="6" md="6" sm="12" className="my-2">
              <div  className="mb-3" style={{textAlign:'justify'}}>
                    <Form.Check
                        inline
                        label="Active"
                        name="active"
                        type='radio'
                        defaultValue={values.active}
                        onChange={handleFormData("active")}                      
                      />                    
                    <Form.Check
                        inline
                        label="InActive"
                        name="inactive"
                        type='radio'
                        defaultValue={values.inactive}
                        onChange={handleFormData("inactive")}                     
                      />
                       {error ? (
                      <Form.Text style={{ color: "red" }}>
                        This is a required field
                      </Form.Text>
                    ) : (
                      ""
                    )}
                  </div> 
              </Col> */}
            </Row>
            <div style={{ display: "flex", justifyContent: "end" }}>
              <Button classNames="allbtncss mx-2" fun={prevStep} type="submit" btnName="Previous"/>
              <Button fun={nextStep2} classNames="allbtncss" type="submit" btnName="Next"/>
            </div>
          </Form>
        </Col>
      
    </>
  );
};

export default StepTwo;