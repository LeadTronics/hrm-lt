import React, { useState } from "react";
import { Form} from "react-bootstrap";
import Button from "../Button/Button";
import validator from "validator";
import { Col,Row } from "react-bootstrap";

// creating functional component ans getting props from app.js and destucturing them
const StepFour = ({ nextStep, handleFormData, prevStep, values }) => {
   //creating error state for validation
  const [error, setError] = useState(false);

 //For file upload set the value of variable
    const[SelectedFile,setSelectedFile]= useState();
    const handleChange =(event)=>{
      console.log(event.target.files[0])  
      setSelectedFile(event.target.files[0])
     
      }

  // after form submit validating the form data using validator
  const submitFormData = (e) => {
    const formData = new FormData();
    formData.append("profile",SelectedFile);
    console.log(formData);
    nextStep();

     // checking if value of first name and last name is empty show error else take to next step
    // if (validator.isEmpty(values.profile)) {
    //   setError(true);
    // } else {
    //   nextStep();
    // }
  };

  //state for steps
  const [step2, setstep2] = useState(4);
  // function for going to next step by increasing step state by 1
     const nextStep2 = () => {
      setstep2(step2 + 1);
    };
  
  // function for going to previous step by decreasing step state by 1
    const prevStep2 = () => {
      setstep2(step2 - 1);
    };

  return (
    <>
      <Col className="perform_box1 my-3">
        {/* Progress Bar */}
        <ul id="progressbar"> 
          <li id="step1" className={step2===1 ? 'active' : 'active2'}  ><strong>Personal Details</strong></li>
          <li  id="step2" className={step2===2 ? 'active' : 'active2'}  ><strong>Company Details</strong></li>
          <li  id="step3" className={step2===3 ? 'active' : 'active2'} ><strong>Bank Details</strong></li>
          <li id="step4"  className={step2===4 ? 'active' : 'active2'}><strong>File Details</strong></li>
        </ul> 
      </Col>
      <Col className="perform_box"> 
        <h5 className='perform_head'>File Details</h5>
          <Form onSubmit={submitFormData}>
            <Row>
              <Col lg="6" md="6" sm="12" className="my-2">
              <div style={{textAlign:'justify'}}>Profile</div>
                <Form.Group className="mb-3">
                    <Form.Control
                      style={{ border: error ? "1px solid red" : "" }}
                      name="profile"
                      defaultValue={values.profile}
                      type="file"
                      placeholder="profile"
                      onChange={handleFormData("profile")}
                    />
                    {error ? (
                      <Form.Text style={{ color: "red" }}>
                        This is a required field
                      </Form.Text>
                    ) : (
                      ""
                    )}
                </Form.Group>
              </Col>
              {/* <Col lg="6" md="6" sm="12" className="my-2">
              <div style={{textAlign:'justify'}}>Pass Photo</div>
                <Form.Group className="mb-3">
                  <Form.Control
                    style={{ border: error ? "1px solid red" : "" }}
                    name="pass_photo"
                    defaultValue={values.pass_photo}
                    type="file"
                    placeholder="pass_photo "
                    onChange={handleFormData("pass_photo")}
                  />
                  {error ? (
                    <Form.Text style={{ color: "red" }}>
                      This is a required field
                    </Form.Text>
                  ) : (
                    ""
                  )}
                </Form.Group>
              </Col> */}
            </Row>
            {/* <Row>
              <Col lg="6" md="6" sm="12" className="my-2">
              <div style={{textAlign:'justify'}}> ID Proof</div>
                <Form.Group className="mb-3">
                    <Form.Control
                      style={{ border: error ? "1px solid red" : "" }}
                      name="ID_proof"
                      defaultValue={values.ID_proof}
                      type="file"
                      placeholder="ID_proof"
                      onChange={handleFormData("ID_proof")}
                    />
                    {error ? (
                      <Form.Text style={{ color: "red" }}>
                        This is a required field
                      </Form.Text>
                    ) : (
                      ""
                    )}
                </Form.Group>
              </Col>
              <Col lg="6" md="6" sm="12" className="my-2">
              <div style={{textAlign:'justify'}}>Offer Latter</div>
                <Form.Group className="mb-3">
                  <Form.Control
                    style={{ border: error ? "1px solid red" : "" }}
                    name="off_latter"
                    defaultValue={values.off_latter}
                    type="file"
                    placeholder="off_latter "
                    onChange={handleFormData("off_latter")}
                  />
                  {error ? (
                    <Form.Text style={{ color: "red" }}>
                      This is a required field
                    </Form.Text>
                  ) : (
                    ""
                  )}
                </Form.Group>
              </Col>
            </Row> */}
            {/* <Row>
              <Col lg="6" md="6" sm="12" className="my-2">
              <div style={{textAlign:'justify'}}>Joinning Latter</div>
                <Form.Group className="mb-3">
                    <Form.Control
                      style={{ border: error ? "1px solid red" : "" }}
                      name="joining_latter"
                      defaultValue={values.joining_latter}
                      type="file"
                      placeholder="joining_latter"
                      onChange={handleFormData("joining_latter")}
                    />
                    {error ? (
                      <Form.Text style={{ color: "red" }}>
                        This is a required field
                      </Form.Text>
                    ) : (
                      ""
                    )}
                </Form.Group>
              </Col>
              <Col lg="6" md="6" sm="12" className="my-2">
              <div style={{textAlign:'justify'}}>Experience Latter</div>
                <Form.Group className="mb-3">
                  <Form.Control
                    style={{ border: error ? "1px solid red" : "" }}
                    name="exp_latter"
                    defaultValue={values.exp_latter}
                    type="file"
                    placeholder="exp_latter "
                    onChange={handleFormData("exp_latter")}
                  />
                  {error ? (
                    <Form.Text style={{ color: "red" }}>
                      This is a required field
                    </Form.Text>
                  ) : (
                    ""
                  )}
                </Form.Group>
              </Col>
            </Row> */}
            <div style={{ display: "flex", justifyContent: "end" }}>
              <Button classNames="allbtncss mx-2" fun={prevStep} type="submit" btnName="Previous"/>
              <Button  classNames="allbtncss" type="submit" btnName="Next"/>
            </div>
          </Form>
        </Col>
      
    </>
  );
};

export default StepFour;