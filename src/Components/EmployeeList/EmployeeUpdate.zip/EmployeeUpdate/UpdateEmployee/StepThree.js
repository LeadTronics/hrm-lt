import React, { useState } from "react";
import { Form } from "react-bootstrap";
import validator from "validator";
import { Col,Row } from "react-bootstrap";
import Button from '../../../Button/Button';

// creating functional component ans getting props from app.js and destucturing them
const StepThree = ({ nextStep, handleFormData, prevStep, values }) => {
   //creating error state for validation
  const [error, setError] = useState(false);

    // after form submit validating the form data using validator
  const submitFormData = (e) => {
    e.preventDefault();

     // checking if value of first name and last name is empty show error else take to next step
    if (validator.isEmpty(values.accName) || validator.isEmpty(values.accno) || validator.isEmpty(values.bank_name)) {
      setError(true);
    } else {
      nextStep();
    }
  };


    //state for steps
    const [step2, setstep2] = useState(3);
    // function for going to next step by increasing step state by 1
       const nextStep2 = () => {
        setstep2(step2 + 1);
      };
    
    // function for going to previous step by decreasing step state by 1
      const prevStep2 = () => {
        setstep2(step2 - 1);
      };

  return (
    <>
    <Col className="perform_box1 my-3">
          {/* Progress Bar */}
            <ul id="progressbar"> 
              <li id="step1" className={step2===1 ? 'active' : 'active2'}  ><strong>Personal Details</strong></li>
              <li  id="step2" className={step2===2 ? 'active' : 'active2'}  ><strong>Company Details</strong></li>
              <li  id="step3" className={step2===3 ? 'active' : 'active2'} ><strong>Bank Details</strong></li>
              <li id="step4"  className={step2===4 ? 'active' : 'active2'}><strong>File Details</strong></li>
            </ul> 
      </Col> 
      
      <Col className="perform_box"> 
        <h5 className='perform_head'>Bank Details</h5>
          <Form onSubmit={submitFormData}>
            <Row>
              <Col lg="6" md="6" sm="12" className="my-2">
                <Form.Group className="mb-3">
                    <Form.Control
                      style={{ border: error ? "1px solid red" : "" }}
                      name="accName"
                      defaultValue={values.accName}
                      type="text"
                      placeholder="Account Name"
                      onChange={handleFormData("accName")}
                    />
                    {error ? (
                      <Form.Text style={{ color: "red" }}>
                        Account Name is a required field
                      </Form.Text>
                    ) : (
                      ""
                    )}
                </Form.Group>
              </Col>
              <Col lg="6" md="6" sm="12" className="my-2">
                <Form.Group className="mb-3">
                  <Form.Control
                    style={{ border: error ? "1px solid red" : "" }}
                    name="accno"
                    defaultValue={values.accno}
                    type="text"
                    placeholder="Account Number "
                    onChange={handleFormData("accno")}
                  />
                  {error ? (
                    <Form.Text style={{ color: "red" }}>
                      Account Number is a required field
                    </Form.Text>
                  ) : (
                    ""
                  )}
                </Form.Group>
              </Col>
            </Row>
            <Row>
              <Col lg="6" md="6" sm="12" className="my-2">
                <Form.Group className="mb-3">
                    <Form.Control
                      style={{ border: error ? "1px solid red" : "" }}
                      name="bank_name"
                      defaultValue={values.bank_name}
                      type="text"
                      placeholder="Bank Name"
                      onChange={handleFormData("bank_name")}
                    />
                    {error ? (
                      <Form.Text style={{ color: "red" }}>
                        Bank Name is a required field
                      </Form.Text>
                    ) : (
                      ""
                    )}
                </Form.Group>
              </Col>
              <Col lg="6" md="6" sm="12" className="my-2">
                <Form.Group className="mb-3">
                  <Form.Control
                    style={{ border: error ? "1px solid red" : "" }}
                    name="branch_name"
                    defaultValue={values.branch_name}
                    type="text"
                    placeholder="Branch Name "
                    onChange={handleFormData("branch_name")}
                  />
                  {error ? (
                    <Form.Text style={{ color: "red" }}>
                      Branch Name is a required field
                    </Form.Text>
                  ) : (
                    ""
                  )}
                </Form.Group>
              </Col>
            </Row>
            <Row>
              <Col lg="6" md="6" sm="12" className="my-2">
                <Form.Group className="mb-3">
                    <Form.Control
                      style={{ border: error ? "1px solid red" : "" }}
                      name="brach_location"
                      defaultValue={values.brach_location}
                      type="text"
                      placeholder="Branch Location"
                      onChange={handleFormData("brach_location")}
                    />
                    {error ? (
                      <Form.Text style={{ color: "red" }}>
                        Branch Location is a required field
                      </Form.Text>
                    ) : (
                      ""
                    )}
                </Form.Group>
              </Col>
              <Col lg="6" md="6" sm="12" className="my-2">
                <Form.Group className="mb-3">
                    <Form.Control
                      style={{ border: error ? "1px solid red" : "" }}
                      name="bank_ifsc"
                      defaultValue={values.bank_ifsc}
                      type="text"
                      placeholder="Bank IFSC"
                      onChange={handleFormData("bank_ifsc")}
                    />
                    {error ? (
                      <Form.Text style={{ color: "red" }}>
                        Bank IFSC is a required field
                      </Form.Text>
                    ) : (
                      ""
                    )}
                </Form.Group>                     
              </Col>
            </Row>
            <Row>
              <Col lg="6" md="6" sm="12" className="my-2">
                <Form.Group className="mb-3">
                    <Form.Control
                      style={{ border: error ? "1px solid red" : "" }}
                      name="Pan"
                      defaultValue={values.Pan}
                      type="text"
                      placeholder="Pan Number"
                      onChange={handleFormData("Pan")}
                    />
                    {error ? (
                      <Form.Text style={{ color: "red" }}>
                        Pan Number is a required field
                      </Form.Text>
                    ) : (
                      ""
                    )}
                </Form.Group>                      
              </Col>
            </Row>
            <div style={{ display: "flex", justifyContent: "end" }}>
              <Button classNames="allbtncss mx-2" fun={prevStep} type="submit" btnName="Previous"/>
              <Button fun={nextStep2} classNames="allbtncss" type="submit" btnName="Next"/>
            </div>
          </Form>
      </Col>
      
    </>
  );
};

export default StepThree;