import './Multistep.css'
import { Container,Row,Col} from 'react-bootstrap';
import React,{useState} from 'react';
import Topbar from '../../../TopBar/Topbar';
import Multistep from './Multistep';
import Footer from '../../../Footer/Footer';

const UpdateEmployee = ()=>{
    return(
        <>
            <div style={{backgroundColor:'#f1f4fb'}}>
                <Topbar/>
                    <div  className='addemp_martop'>
                        <Row>
                            <Multistep  />                            
                        </Row>
                    </div> 
                <Footer />
            </div>
        </>
    )
}
export default UpdateEmployee; 