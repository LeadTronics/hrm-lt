import React from "react";
import { Card ,Col} from "react-bootstrap";
import Button from '../../../Button/Button';
import { Link } from 'react-router-dom';

const Final = ({ values }) => {

    //destructuring the object from values
  const { Name, Busi_email, empid, department ,accName} = values;
  return (
    <>
    <Col className="perform_box"> 
    <h5 className='perform_head'>Final Details</h5>
      <Card style={{ textAlign: "left" }}>
        <Card.Body>
          <p>
            <strong>Name :</strong> {Name}{" "}
          </p>
          <p>
            <strong>Business Email:</strong> {Busi_email}{" "}
          </p>
          <p>
            <strong>Employee Id :</strong> {empid}{" "}
          </p>
          <p>
            <strong>Email :</strong> {department}{" "}
          </p>
          <p><strong>Account Name:</strong> {accName}{""}</p>
        </Card.Body>
      </Card>
        <div className="my-2">
          <Link to="/allemployee"> 
              <Button classNames="allbtncss" type="submit" btnName="Save Data"/>
          </Link>
        </div>
    </Col>
    </>
  );
};

export default Final;